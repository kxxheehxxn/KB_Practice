<script setup>
import Calc from './components/Calc.vue';
import Calc2 from './components/Calc2.vue';
import Calc3 from './components/Calc3.vue';
import Calc4 from './components/Calc4.vue';
import Calc5 from './components/Calc5.vue';
</script>

<template>
  <div>
    <Calc />
    <br />
    <hr />
    <Calc2 />
    <br />
    <hr />
    <Calc3 />
    <br />
    <hr />
    <Calc4 />
    <br />
    <hr />
    <Calc5 />
  </div>
</template>

<style scoped></style>
